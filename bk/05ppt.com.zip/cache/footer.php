<footer class="center footer phonehide">
        <p class="copyright tacenter"><?php echo $this->vars["hl1"] ?> <script><?php echo $this->vars["hl2"] ?></script></p>
</footer>
<div class="quick fix phonehide">
        <ul>
            <li class="b"><img src="<?php echo TU ?>/r1.png" /></li>
            <li class="a">
                <a href="<?php echo INDEX ?>/download.html">
                    <img src="<?php echo TU ?>/r2.png" />
                    <span>下载</span>
                </a>
            </li>
            <li>
                <a href="<?php echo INDEX ?>/customer.html">
                    <img src="<?php echo TU ?>/r3.png" />
                    <span>客服</span>
                </a>
            </li>
            <li>
                <a href="javascript:;" class="returntop">
                    <img src="<?php echo TU ?>/r4.png" />
                    <span>顶部</span>
                </a>
            </li>
            <div class="clear"></div>
        </ul>
</div>
