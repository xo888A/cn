<ul class="tag">
    <li>
        <span><a href="<?php echo INDEX ?>/admin.php?mod=index"><i class="fa fa-home"></i></a></span>
    </li>
    <li><img src="<?php echo IMG ?>/right1.jpg" /></li>
    <li><a href="<?php echo INDEX ?>/index.gsp">首页</a></li>
    <li><img src="<?php echo IMG ?>/right1.jpg" /></li>
    <li><?php echo $this->vars["show"] ?></li>
    <li><img src="<?php echo IMG ?>/right2.jpg" /></li>
    <div class="clear"></div>
</ul>