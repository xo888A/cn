<?php
    if(!defined('CW')){exit('Access Denied');}
    require "library/language/cn.php";
    require "library/functions.php";
    require "adapter/adapter.php";
    require "config/global_config.php";
    require "library/file.php";
    
    require "system.php";
    require "library/dbserver.php";
    
    
?>