<?php
    
    define('home','首页');
    define('video','视频');
    define('shortvideo','短视频');
    define('shequ','社区');
    define('my','我的');

    define('activity_a1',"活动");
    define('activity_a2',"平台通知");
    define('activity_a3',"官方消息");
    define('activity_a4',"官方活动");
    define('activity_a5',"推荐APP");
    define('albuy_1',"已购影片");
    
    define('alltopiclist_1',"话题板块");
    define('alltopiclist_2',"全部话题");
    define('alltopiclist_3',"分类菜单");
    
    define('app_1',"推荐APP");
    define('app_2',"平台通知");
    define('app_3',"官方消息");
    define('app_4',"官方活动");
    define('app_5',"推荐APP");
    
    define('author_1',"粉丝");
    define('author_2',"作品");
    define('author_3',"全部动态");
    define('author_4',"视频");
    define('author_5',"社区");
    
    define('card_1',"卡密兑换");
    define('card_2',"使用卡密兑换VIP/金币");
    define('card_3',"使用卡密");
    define('card_4',"确认兑换");
    define('card_5',"每张卡密仅限使用一次");
    define('card_6',"复制你购买的卡密粘贴到上面输入框即可兑换");
    define('card_7',"需要帮助请联系人工客服帮助");
    
    define('concern_1',"我的关注");
    
    define('customer_1',"客服中心");
    define('customer_2',"嘿，朋友！您遇到问题了吗？请与我们的专业客服团队联系，我们有备而来训练有素，在您使用本站服务遇到的任何问题，可为您提供全程指导直至成功解决！");
    define('customer_3',"在线客服");
    define('customer_4',"备用客服");
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
?>