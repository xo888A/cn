<footer class="fix w100">
        <ul class="overflow">
            <li class="<?php echo $this->vars["a"] ?>">
                <a href="./index.php?mod=index">
                <img src="../image/a1<?php echo $this->vars["_a"] ?>.png" />
                <p>首页</p></a>
            </li>
            <li class="<?php echo $this->vars["b"] ?>">
                <a href="./index.php?mod=videolist">
                <img src="../image/a2<?php echo $this->vars["_b"] ?>.png" />
                <p>视频</p></a>
            </li>
            <li class="<?php echo $this->vars["c"] ?>">
                <a href="./index.php?mod=shortvideo">
                <img src="../image/a3<?php echo $this->vars["_c"] ?>.png" />
                <p>短视频</p></a>
            </li>
            <li class="<?php echo $this->vars["d"] ?>">
                <a href="./index.php?mod=organlist">
                <img src="../image/a4<?php echo $this->vars["_d"] ?>.png" />
                <p>社区</p></a>
            </li>
            <li class="<?php echo $this->vars["e"] ?>">
                <a href="./index.php?mod=user">
                <img src="../image/a5<?php echo $this->vars["_e"] ?>.png" />
                <p>我的</p></a>
            </li>
        </ul>
    </footer>
    
    <!--<div class="bqn"><script><?php echo $this->vars["hl2"] ?></script></div>-->
   